filename PFB8DCC4 list;

 %put NOTE- ;
 %put NOTE: Data for package sas_dataset_toon, version 1.0.0, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2025-11-18T07:39:15; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Write %nrstr(%%)helpPackage(sas_dataset_toon) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_;
 length lazyData $ 32767; lazyData = lowcase(symget("lazyData"));
run;
%put NOTE- ;
%put NOTE: Data for package sas_dataset_toon, version 1.0.0, license MIT;
%put NOTE- *** END ***;

/* lazydata.sas end */

